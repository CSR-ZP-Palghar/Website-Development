<section id="footer">
            <div class="container">
                <div class="row text-center">
                    <div class="col-md-6">
                        <div class="copyright">
                            <p>@ May, 2018 - Design By <span><a href="http://www.ctara.iitb.ac.in/">CTARA, IIT BOMBAY</a></span></p>
                            <p> Supported By  <img src="img/unicef_logo.png" width="100px" height="30px"></p>
                        </div>
                    </div>
                   
                </div>
                <!--End of row-->
            </div>
            <!--End of container-->
        </section>
        <!--End of footer-->