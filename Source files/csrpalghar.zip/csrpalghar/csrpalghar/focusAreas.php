﻿<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Focus Areas</title>

        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>

        <link rel="stylesheet" href="css/font-awesome.min.css">
	
        <link rel="stylesheet" type="text/css" href="css/animate.min.css">

        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" rel="stylesheet" href="css/carousel.css" />

        <link rel="stylesheet" href="css/isotope/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="css/style.css" rel="stylesheet">
        <link href="css/responsive.css" rel="stylesheet">

	<style>
.dropbtn {
background-color: white;
    padding: 16px;
    border: none;
    text-decoration: none;
}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #ddd}

.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: white;
}
</style>

    </head>

    <body data-spy="scroll" data-target="#header">

        <!--Start Hedaer Section-->
        <section id="header">
            <div class="header-area">
                
                <!--End of top header-->
                <div class="header_menu text-center" data-spy="affix" data-offset-top="50" id="nav">
                    <div class="contact">
                        <nav class="navbar navbar-default zero_mp">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class="navbar-header">
                                
                                <a class="navbar-brand custom_navbar-brand" href="#"><img src="img/new_logo.png" width="200px"  alt=""></a>
                            </div>
                            <!--End of navbar-header-->

                            <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="collapse navbar-collapse zero_mp" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right main_menu">
                                    <li  ><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
                                    <li ><a href="roles.php">Roles and Responsibility</a></li>
                                    <li class="active"><a href="focusAreas.php">Focus Areas</a></li>
                                    
                                    <li><div class="dropdown">
  <a href="#"><button class="dropbtn">GRAMPANCHAYAT-WISE REQUIREMENTS</button></a>
  <div class="dropdown-content">
    <a href="dahanu.php">DAHANU</a>
    <a href="jawhar.php">JAWHAR</a>
    <a href="mokhada.php">MOKHADA</a>
    <a href="palghar.php">PALGHAR</a>
    <a href="talasari.php">TALASARI</a>
    <a href="vasai.php">VASAI</a>	
    <a href="vikramgarh.php">VIKRAMGARH</a>
    <a href="wada.php">WADA</a>		
  </div>
</div>	</li>
<li><a href="partners.php">Our Partners</span></a></li>
                                    <li><a href="contact.php">contact us</a></li>
                                </ul>

                            <!-- /.navbar-collapse -->
                        </nav>
                        <!--End of nav-->
                    </div>
                    <!--End of container-->
                </div>
                <!--End of header menu-->
            </div>
            <!--end of header area-->
        </section>
        <!--End of Hedaer Section-->



        <!--Start of slider section-->
        


        <!--Start of welcome section-->
        <section id="welcome">
		  <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="wel_header">
                            <h2>Key Focus Areas</h2>
			<p><font size=4px>Based on a detailed need analysis and intense consultation with all stakeholders, 
the District CSR Cell has identified the following domains for affirmative action. </font></p>
                        </div>
                    </div>
                </div>
                <!--End of row-->
                <div class="row">
                    <div class="col-md-3">
                        <div class="item">
                            <div class="single_item">
                                <div class="item_list">
                                    <div >
                                        <img src="img/educations.png"  height="120px" width="120px">
                                    </div>
                                    <h4>Education</h4>
                                </div>
                            </div>
                        </div>
                    </div>

			
			<div class="col-md-3">
                        <div class="item">
                            <div class="single_item">
                                <div class="item_list">
                                    <div>
                                        <img src="img/health.png" height="120px" width="120px">
                                    </div>
                                    <h4>Health</h4>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-3-->
                    <div class="col-md-3">
                        <div class="item">
                            <div class="single_item">
                                <div class="item_list">
                                    <a href="#volunteer">
                                    <div >
                                       <img src="img/nuetrition.png"  height="120px" width="120px">
                                        
                                    </div>
                                    <h4>nutrition (ICDS)</h4>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-3-->
                    <div class="col-md-3">
                        <div class="item">
                            <div class="single_item">
                                <div class="item_list">
                                   <div >
                                       <img src="img/sanitation.png"  height="120px" width="120px">
                                        
                                    </div>
                                    <h4>WATER SANITATION AND HYGIENE (WASH)</h4>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-3-->
                    
	
                    <!--End of col-md-3-->
                </div>

	<div>
            <!--End of container-->
       <BR><BR>
		  <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="wel_header">
                            <h2><div >
                                       <img src="img/educations.png"  height="120px" width="120px">
                                        
                                    </div><br>
                                    <font color="#004C6C">Education</font></h2>
			<p><font size=4px>The emphasis is to supplement infrastructure so that more students are encouraged
to attend schools and the schools are empowered to provide better education. </font></p>
                        </div>
                    </div>
                </div>
                <!--End of row-->
                <div class="row">
                    <div class="col-md-3">
                        <div class="item">
                            <div class="single_item">
                                <div class="item_list">
                                    <div >
                                       <img src="img/sanitation.png"  height="120px" width="120px">
                                        
                                    </div>
                                    <h4>Building toilet blocks in schools</h4>
                                </div>
                            </div>
                        </div>
                    </div>	

			
			<div class="col-md-2">
                        <div class="item">
                            <div class="single_item">
                                <div class="item_list">
                                    <div >
                                       <img src="img/sci.png"  height="120px" width="120px">
                                        
                                    </div>
                                    <h4>Modernising science laboratory in secondary schools</h4>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-3-->
                    <div class="col-md-3">
                        <div class="item">
                            <div class="single_item">
                                <div class="item_list">
                                    <div>
                                       <img src="img/cctv.png"  height="120px" width="120px">
                                        
                                    </div>
                                    <h4>Installing CCTV camera in schools</h4>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-3-->
                    <div class="col-md-2">
                        <div class="item">
                            <div class="single_item">
                                <div class="item_list">
                                    <div >
                                       <img src="img/sports.png"  height="120px" width="120px">
                                        
                                    </div>
                                    <h4>Providing sports and music equipment in schools</h4>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-3-->
                    <div class="col-md-2">
                        <div class="item">
                            <div class="single_item">
                                <div class="item_list">
                                   <div >
                                       <img src="img/wheel.png"  height="120px" width="120px">
                                        
                                    </div>
                                    <h4>Science-on-wheels</h4>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
<div class="col-md-2">
                       
                    </div>
	
        </section>


        <!--Start of volunteer-->
        
	<section id="portfolio" class="text-center">
		<div class="container">
            <div class="col-md-12">
                <div class="wel_header">
                    <h2>
                        <div>
                        <img src="img/health.png"  height="120px" width="120px">
                        </div> <br>
                        <font color="#FD1852">Health</font>
                    </h2><br>
                </div>    
            
            </div>
            <img src="img/nhealth.jpg">
            </div>
	
    </section>

<section id="volunteer">
            <div class="container">
                <div class="row vol_area">
                   <center> <div class="col-md-15">
                        <div class="volunteer_content">
                            <div class="wel_header">
                            <h2>
                        <div>
                        <img src="img/nuetrition.png"  height="120px" width="120px">
                        </div>
                        <font color="#66A64D"><span>Nutrition</span></font>
                    </h2>  </div>
                            <p><font size="4px">The aim is to provide training and employment opportunities which help marginalised segments of society to improve their quality of life.</font></p>
                        </div>
                    </div>
			</center>
<br>

<div class="row">
                                <div class="col-md-12 text-center">
                                    <div class="carousel slide" id="fade-quote-carousel" data-ride="carousel" data-interval="3000">
                                        <div class="carousel-inner">
                                            <div class="active item">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="testimonial_content">
                                                            <i class="fa fa-quote-left"></i>
                                                            <p></p>
                                                        </div>
                                                        
                                                    </div>
						   
                                                    <div class="col-md-6">
                                                        
                                                        <div class="testimonial_content">
                                                            <i class="fa fa-quote-left"></i>
                                                            <p></p>
                                                        </div>
                                                       
                                                    </div>
						
                                                </div>
                                            </div>
					    
                                        </div>
                                    </div>
                                </div>
                            </div>
			 </div>
                <!--End of row and vol_area-->
            </div>
            <!--End of container-->
        </section>
        <!--end of volunteer-->


	<section id="portfolio" class="text-center">
		<div class="container">
            <div class="col-md-12">
                <div class="portfolio_title" >
                    <div class="wel_header">
                 <h2>
                        <div>
                        <img src="img/sanitation.png"  height="120px" width="120px">
                        </div>
                        <font color="#008297"><span>Water Sanitation and Hygiene (WaSH)</span></font>
                    </h2>
                </div>
                    <p><font size=4px>The attention is on the household sanitation and drinking water facility.</font><br> <h3> <font color="#008297">The initiatives include: </font></h3></p>
                </div>
            </div>

<section id="blog">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="blog_news">
                            <div class="single_blog_item">
                                
                                <div class="blog_content" style="background-color:#008297">
                                   <h3><font color="white">Identification of gaps for the facilities of household sanitation and drinking water, with the list of industries located in the surrounding areas who can extend their CSR activities in these areas.</font></h3>
                                    
                              
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-4-->
                    <div class="col-md-4">
                        <div class="blog_news">
                            <div class="single_blog_item">
                               
                                <div class="blog_content" style="background-color:#008297">
                                    <h3> <font color="white">'Swachh Bharat' and 'Nirmal Bharat Abhiyan' initiative for solid and liquid waste management plus prevention of open defecation for towns and villages.</font></h3>
                                 
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-4-->
                    <div class="col-md-4">
                        <div class="blog_news">
                            <div class="single_blog_item">
                                
                                <div class="blog_content" style="background-color:#008297">
                                   <h3> <font color="white">Construction of sanitation blocks in households, schools and anganwadis.</font></h3>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
			
                    <!--End of col-md-4-->
                </div>
		<br>
		<div class="row">
                    <div class="col-md-4">
                        <div class="blog_news">
                            <div class="single_blog_item">
                                
                                <div class="blog_content" style="background-color:#008297">
                                    <h3><font color="white">Providing drinking water facility in deprived pockets.</font></h3>
                                  
                               
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-4-->
                    <div class="col-md-4">
                        <div class="blog_news">
                            <div class="single_blog_item">
                               
                                <div class="blog_content" style="background-color:#008297">
                                   <h3><font color="white"> How to avoid indoor air pollution? </font></h3>
                                    

                                    <p class="blog_news_content"></p>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-4-->
                    <div class="col-md-4">
                        <div class="blog_news">
                            <div class="single_blog_item">
                                
                                <div class="blog_content" style="background-color:#008297">
                                   <h3><font color="white">Threat to Yellowstone’s grizzly bears. </font></h3>
                                    

                                    <p class="blog_news_content"></p>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
			
                    <!--End of col-md-4-->
                </div>
                <!--End of row-->
            </div>
		</div>
            <!--End of container-->
        </section>
        <!--end of portfolio-->





        <!--end of volunteer-->

        <!--Start of portfolio-->
        <!--end of portfolio-->
</section>

        <!--Start of footer-->
        <?php
       include "footer.php";
       ?>


        <!--Scroll to top-->
        <a href="#" id="back-to-top" title="Back to top">&uarr;</a>
        <!--End of Scroll to top-->


        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <!-- <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js'></script>-->
        <script src="js/jquery-1.12.3.min.js"></script>

        <!--Counter UP Waypoint-->
        <script src="js/waypoints.min.js"></script>
        <!--Counter UP-->
        <script src="js/jquery.counterup.min.js"></script>

        <script>
            //for counter up
            $('.counter').counterUp({
                delay: 10,
                time: 1000
            });
        </script>

        <!--Gmaps-->
        <script src="js/gmaps.min.js"></script>
        <script type="text/javascript">
            var map;
            $(document).ready(function () {
                map = new GMaps({
                    el: '#map',
                    lat: 23.6911078,
                    lng: 90.5112799,
                    zoomControl: true,
                    zoomControlOpt: {
                        style: 'SMALL',
                        position: 'LEFT_BOTTOM'
                    },
                    panControl: false,
                    streetViewControl: false,
                    mapTypeControl: false,
                    overviewMapControl: false,
                    scrollwheel: false,
                });


                map.addMarker({
                    lat: 23.6911078,
                    lng: 90.5112799,
                    title: 'Office',
                    details: {
                        database_id: 42,
                        author: 'Foysal'
                    },
                    click: function (e) {
                        if (console.log)
                            console.log(e);
                        alert('You clicked in this marker');
                    },
                    mouseover: function (e) {
                        if (console.log)
                            console.log(e);
                    }
                });
            });
        </script>
        <!--Google Maps API-->
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBjxvF9oTfcziZWw--3phPVx1ztAsyhXL4"></script>


        <!--Isotope-->
        <script src="js/isotope/min/scripts-min.js"></script>
        <script src="js/isotope/cells-by-row.js"></script>
        <script src="js/isotope/isotope.pkgd.min.js"></script>
        <script src="js/isotope/packery-mode.pkgd.min.js"></script>
        <script src="js/isotope/scripts.js"></script>


        <!--Back To Top-->
        <script src="js/backtotop.js"></script>


        <!--JQuery Click to Scroll down with Menu-->
        <script src="js/jquery.localScroll.min.js"></script>
        <script src="js/jquery.scrollTo.min.js"></script>
        <!--WOW With Animation-->
        <script src="js/wow.min.js"></script>
        <!--WOW Activated-->
        <script>
            new WOW().init();
        </script>


        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="js/bootstrap.min.js"></script>
        <!-- Custom JavaScript-->
        <script src="js/main.js"></script>
    </body>

</html>
