<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Contact Us</title>

        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>

        <link rel="stylesheet" href="css/font-awesome.min.css">
	
        <link rel="stylesheet" type="text/css" href="css/animate.min.css">

        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" rel="stylesheet" href="css/carousel.css" />
        <script src="js/map.js"></script>
        <link rel="stylesheet" href="css/isotope/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="css/style.css" rel="stylesheet">
        <link href="css/responsive.css" rel="stylesheet">

	<style>
.dropbtn {
background-color: white;
    padding: 16px;
    border: none;
    text-decoration: none;
}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #ddd}

.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: white;
}
#map_wrapper {
    height: 400px;
}

#map_canvas {
    width: 100%;
    height: 100%;
}


</style>



    </head>

    <body data-spy="scroll" data-target="#header">

        <!--Start Hedaer Section-->
        <section id="header">
            <div class="header-area">
                
                <!--End of top header-->
                <div class="header_menu text-center" data-spy="affix" data-offset-top="50" id="nav">
                    <div class="contact">
                        <nav class="navbar navbar-default zero_mp">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
 <a class="navbar-brand custom_navbar-brand" href="#"><img src="img/new_logo.png" width="230px"  alt=""></a>
                            </div>
                            <!--End of navbar-header-->

                            <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="collapse navbar-collapse zero_mp" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right main_menu">
                                    <li  ><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
                                    <li ><a href="roles.php">Roles and Responsibility</a></li>
                                    <li><a href="focusAreas.php">Focus Areas</a></li>
                                    
                                    <li><div class="dropdown">
  <a href="#"><button class="dropbtn">GRAMPANCHAYAT-WISE REQUIREMENTS</button></a>
  <div class="dropdown-content">
    <a href="dahanu.php">DAHANU</a>
    <a href="jawhar.php">JAWHAR</a>
    <a href="mokhada.php">MOKHADA</a>
    <a href="palghar.php">PALGHAR</a>
    <a href="talasari.php">TALASARI</a>
    <a href="vasai.php">VASAI</a>	
    <a href="vikramgarh.php">VIKRAMGARH</a>
    <a href="wada.php">WADA</a>		
  </div>
</div>	</li>
<li><a href="partners.html">Our Partners</span></a></li>
                                    <li class="active"><a href="contact.php">contact us</a></li>
                                </ul>

                            <!-- /.navbar-collapse -->
                        </nav>
                        <!--End of nav-->
                    </div>
                    <!--End of container-->
                </div>
                <!--End of header menu-->
            </div>
            <!--end of header area-->
        </section>
        <!--End of Hedaer Section-->



        <!--Start of slider section-->
        

        <!--Start of welcome section-->
       <!--Start of contact-->
        <section id="contact">
            <div class="container">
                <div class="row">
                    <div class="colmd-12">
                        <div class="contact_area text-center">
                            <h3>get in touch</h3>
                            
                        </div>
                    </div>
                    
                    
                    
                    <div class="container text-center">
<div class="containerSm">
<div class="row vdivideGreen">
<div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 text-center">
   
<div class="text-center"><img src="img/new_logo.png" height="300px" width="300px"></div>
<div class="bodytext text-center topPadding20">CEO Office,</div>
<div class="bodytext text-center">Zilla Parishad Building</div>
<div class="bodytext text-center">Near SP Office, Palghar-401404</div>
            
</div>

<div class="col-md-6 col-lg-6 col-sm-6 col-xs-12 text-center rowTop3">
<div class="text-center"><img src="img/telephone.png" widht="10px" height="10px"></div>
<div class="bodytext text-center topPadding10">For Further Details, Contact:</div>
<div class="bodytext3Green text-center topPadding15">Digvijay Bendrikar Shinde</div>
<div class="bodytext text-center">Co-ordinator Social Transformation Cell</div>
<div class="bodytext text-center topPadding5">M: +917506191673  |  <a href="mailto:csrzppalghar@gmail.com" style="color:#333; text-decoration:none;">csrzppalghar@gmail.com</a></div>
<div class="bodytext3Green text-center topPadding15">Ms. Manisha</div>
<div class="bodytext text-center">Co-ordinator Social Transformation Cell</div>
<div class="bodytext text-center topPadding5">M: +918830327106 |  <a href="mailto:pro.zppalghar@gmail.com" style="color:#333; text-decoration:none;">pro.zppalghar@gmail.com</a></div>

</div>
</div>
</div>
  <div id="container">
   <script src='https://maps.googleapis.com/maps/api/js?key=AIzaSyBfBOVWIVUGOH26wYLxwEEwqcjVB0PFHXk'></script><div style='overflow:hidden;width:450px;height:350px;'><br><br><div id='gmap_canvas' style='width:450px;height:350px;'></div></div><script type='text/javascript'>function init_map(){var myOptions = {zoom:12,center:new google.maps.LatLng(19.1340894,72.91606890000003),mapTypeId: google.maps.MapTypeId.ROADMAP};map = new google.maps.Map(document.getElementById('gmap_canvas'), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(19.1340894,72.91606890000003)});infowindow = new google.maps.InfoWindow({content:'<strong>Mumbai Office</strong><br>CTARA, IIT Bombay, 400076<br>'});google.maps.event.addListener(marker, 'click', function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);</script>   
</div>

</div>
                   
                </div>
                <!--End of row-->
              
                   
                <!--End of row-->
            </div>
            
        
            <!--End of container-->
      
            
        </section><!--End of contact-->


              
        <!--Start of footer-->
       <?php
       include "footer.php";
       ?>



        <!--Scroll to top-->
        <a href="#" id="back-to-top" title="Back to top">&uarr;</a>
        <!--End of Scroll to top-->


        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <!-- <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js'></script>-->
        <script src="js/jquery-1.12.3.min.js"></script>

        <!--Counter UP Waypoint-->
        <script src="js/waypoints.min.js"></script>
        <!--Counter UP-->
        <script src="js/jquery.counterup.min.js"></script>

        <script>
            //for counter up
            $('.counter').counterUp({
                delay: 10,
                time: 1000
            });
        </script>

        <!--Gmaps-->
        <script src="js/gmaps.min.js"></script>
        <script type="text/javascript">
            var map;
            $(document).ready(function () {
                map = new GMaps({
                    el: '#map',
                    lat: 23.6911078,
                    lng: 90.5112799,
                    zoomControl: true,
                    zoomControlOpt: {
                        style: 'SMALL',
                        position: 'LEFT_BOTTOM'
                    },
                    panControl: false,
                    streetViewControl: false,
                    mapTypeControl: false,
                    overviewMapControl: false,
                    scrollwheel: false,
                });


                map.addMarker({
                    lat: 23.6911078,
                    lng: 90.5112799,
                    title: 'Office',
                    details: {
                        database_id: 42,
                        author: 'Foysal'
                    },
                    click: function (e) {
                        if (console.log)
                            console.log(e);
                        alert('You clicked in this marker');
                    },
                    mouseover: function (e) {
                        if (console.log)
                            console.log(e);
                    }
                });
            });
        </script>
        <!--Google Maps API-->
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBjxvF9oTfcziZWw--3phPVx1ztAsyhXL4"></script>


        <!--Isotope-->
        <script src="js/isotope/min/scripts-min.js"></script>
        <script src="js/isotope/cells-by-row.js"></script>
        <script src="js/isotope/isotope.pkgd.min.js"></script>
        <script src="js/isotope/packery-mode.pkgd.min.js"></script>
        <script src="js/isotope/scripts.js"></script>
        <link href="css/default.css" rel="stylesheet">

        <!--Back To Top-->
        <script src="js/backtotop.js"></script>


        <!--JQuery Click to Scroll down with Menu-->
        <script src="js/jquery.localScroll.min.js"></script>
        <script src="js/jquery.scrollTo.min.js"></script>
        <!--WOW With Animation-->
        <script src="js/wow.min.js"></script>
        <!--WOW Activated-->
        <script>
            new WOW().init();
        </script>


        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="js/bootstrap.min.js"></script>
        <!-- Custom JavaScript-->
        <script src="js/main.js"></script>
    </body>

</html>
