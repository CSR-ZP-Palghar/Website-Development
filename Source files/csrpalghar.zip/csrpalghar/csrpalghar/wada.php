﻿<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Wada</title>

        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>

        <link rel="stylesheet" href="css/font-awesome.min.css">
	
        <link rel="stylesheet" type="text/css" href="css/animate.min.css">

        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" rel="stylesheet" href="css/carousel.css" />

        <link rel="stylesheet" href="css/isotope/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="css/style.css" rel="stylesheet">
        <link href="css/responsive.css" rel="stylesheet">

	<style>
.dropbtn {
background-color: white;
    padding: 16px;
    border: none;
    text-decoration: none;
}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #ddd}

.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: white;
}

.button {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}
input[type=submit] {
    width: 40%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #45a049;
}
select {
    width: 40%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}
#customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

#customers td, #customers th {
    padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}


#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
}
</style>


    </head>

    <body data-spy="scroll" data-target="#header">

        <!--Start Hedaer Section-->
        <section id="header">
            <div class="header-area">
                
                <!--End of top header-->
                <div class="header_menu text-center" data-spy="affix" data-offset-top="50" id="nav">
                    <div class="contact">
                        <nav class="navbar navbar-default zero_mp">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                 <a class="navbar-brand custom_navbar-brand" href="#"><img src="img/new_logo.png" width="200px"  alt=""></a>
                            </div>
                            <!--End of navbar-header-->

                            <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="collapse navbar-collapse zero_mp" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right main_menu">
                                    <li><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
                                    <li><a href="roles.php">Roles and Responsibility</a></li>
                                    <li><a href="focusAreas.php">Focus Areas</a></li>
                                    
                                    
                                <li class="active">    
				<div class="dropdown">
  <a href="#"><button class="dropbtn">GRAMPANCHAYAT-WISE REQUIREMENTS</button></a>
  <div class="dropdown-content">
    <a href="dahanu.php">DAHANU</a><br>
    <a href="jawhar.php">JAWHAR</a><br>
    <a href="mokhada.php">MOKHADA</a><br>
    <a href="palghar.php">PALGHAR</a><br>
    <a href="talasari.php">TALASARI</a><br>
    <a href="vasai.php">VASAI</a>	<br>
    <a href="vikramgarh.php">VIKRAMGARH</a><br>
    <a href="wada.php">WADA</a>		<br>
  </div>
</div>		

</li>
<li><a href="partners.php">our partners</a></li>
<li><a href="contact.php">contact us</a></li>
                                </ul>

                            <!-- /.navbar-collapse -->
                        </nav>
                        <!--End of nav-->
                    </div>
                    <!--End of container-->
                </div>
                <!--End of header menu-->
            </div>
            <!--end of header area-->
        </section>
        <!--End of Hedaer Section-->




        


        <!--Start of welcome section-->
        <section id="welcome">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="wel_header">
                            <h2>welcome to WADA TALUK</h2>
                            <p>Select the Gram-Panchayat to view Grampanchayat-wise Requirements</p>
                        </div>
                    </div>
	                </div><br><br>
<form name="frm" method="POST" action="wada.php">
    <center>
    <table id="customers">
        <tr>
            <td align="right">
                <select name="gp" id="select" class="dropdown"></select>
            </td>
            <td  >
                <input type="Submit" name="button" value="Get Grampanchayat Data">                
            </td>
        </tr>
    </table>
    </center>
</form>

<?php if(isset($_POST["button"]))
include "gpwise.php";
?>

        </section>
 
<br><br><br>       
        <?php 
        include "footer.php"
        ?>


        <!--Scroll to top-->
        <a href="#" id="back-to-top" title="Back to top">&uarr;</a>
        <!--End of Scroll to top-->


        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <!-- <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js'></script>-->
        <script src="js/jquery-1.12.3.min.js"></script>

        <!--Counter UP Waypoint-->
        <script src="js/waypoints.min.js"></script>
        <!--Counter UP-->
        <script src="js/jquery.counterup.min.js"></script>

        <script>
            //for counter up
            $('.counter').counterUp({
                delay: 10,
                time: 1000
            });
        </script>

        <!--Gmaps-->
        <script src="js/gmaps.min.js"></script>
        <script type="text/javascript">
            var map;
            $(document).ready(function () {
                map = new GMaps({
                    el: '#map',
                    lat: 23.6911078,
                    lng: 90.5112799,
                    zoomControl: true,
                    zoomControlOpt: {
                        style: 'SMALL',
                        position: 'LEFT_BOTTOM'
                    },
                    panControl: false,
                    streetViewControl: false,
                    mapTypeControl: false,
                    overviewMapControl: false,
                    scrollwheel: false,
                });


                map.addMarker({
                    lat: 23.6911078,
                    lng: 90.5112799,
                    title: 'Office',
                    details: {
                        database_id: 42,
                        author: 'Foysal'
                    },
                    click: function (e) {
                        if (console.log)
                            console.log(e);
                        alert('You clicked in this marker');
                    },
                    mouseover: function (e) {
                        if (console.log)
                            console.log(e);
                    }
                });
            });
        </script>
        <!--Google Maps API-->
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBjxvF9oTfcziZWw--3phPVx1ztAsyhXL4"></script>


        <!--Isotope-->
        <script src="js/isotope/min/scripts-min.js"></script>
        <script src="js/isotope/cells-by-row.js"></script>
        <script src="js/isotope/isotope.pkgd.min.js"></script>
        <script src="js/isotope/packery-mode.pkgd.min.js"></script>
        <script src="js/isotope/scripts.js"></script>


        <!--Back To Top-->
        <script src="js/backtotop.js"></script>


        <!--JQuery Click to Scroll down with Menu-->
        <script src="js/jquery.localScroll.min.js"></script>
        <script src="js/jquery.scrollTo.min.js"></script>
        <!--WOW With Animation-->
        <script src="js/wow.min.js"></script>
        <!--WOW Activated-->
        <script>
            new WOW().init();
        </script>


        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="js/bootstrap.min.js"></script>
        <!-- Custom JavaScript-->
        <script src="js/main.js"></script>

	<script>

		var select = document.getElementById("select");
var options = [
  ["ABJE"],
  ["AINSHET"],
  ["AKHADA"],
  ["ALMAN"],
  ["AMBHAI"],
  ["AMBISTE BK"],
  ["BALIVALI"],
  ["BHAVEGHAR"],
  ["BILAVALI"],
  ["BILGHAR"],
  ["BILOSHI"],
  ["BUDHAVALI"],
  ["CHAMBALE"],
  ["CHIKHALE"],
  ["CHINCHGHAR"],
  ["DAHE"],
  ["DAKIVALI"],
  ["DEVALI"],
  ["DEVGHAR"],
  ["DONGASTE"],
  ["GALTARE"],
  ["GANDHRE"],
  ["GARGAON"],
  ["GATES BK"],
  ["GAURAPUR"],
  ["GHONSAI"],
  ["GORAD"],
  ["GORHE"],
  ["GUHIR"],
  ["GUNJ"],
  ["HAMARAPUR"],
  ["HAROSALE"],
  ["JAMGHAR"],
  ["KALAMBHE"],
  ["KALAMKHAND"],
  ["KAMBARE"],
  ["KANCHAD"],
  ["KELTHAN"],
  ["KHAIRE AMBIVALI"],
  ["KHANIVALI"],
  ["KHARIVALI"],
  ["KHUPARI"],
  ["KONDHALE"],
  ["KONE"],
  ["KONSAI"],
  ["KUDUS"],
  ["KUYALU"],
  ["MANDA"],
  ["MANDAVA"],
  ["MANGROOL"],
  ["MANIVALI"],
  ["MOJ"],
  ["MUSARANE"],
  ["NANDANI"],
  ["NARE"],
  ["NEHAROLI"],
  ["NICHOLE"],
  ["OGADA"],
  ["PALSAI"],
  ["PARALI"],
  ["PIK"],
  ["PIMPALAS"],
  ["POSHERI"],
  ["SANGE"],
  ["SAPANE BK"],
  ["SAPRONDE"],
  ["SARASOHAL"],
  ["SARSHI"],
  ["SHELE"],
  ["SHELTE"],
  ["SHIRSAD-KASGHAR"],
  ["SONALE BK"],
  ["SONSHIV"],
  ["SUPONDE"],
  ["TILGAON"],
  ["TUSE"],
  ["UCHAT"],
  ["UJJAINI"],
  ["USAR"],
  ["VADAVALI"],
  ["VARALE"],
  ["VARSALE"],
  ["VASURI BK"]
]
;

select.innerHTML = options.map(function(option) {
  return "<option>" + option + "</option>";
}).join("");
</script>


<script>
function optionCheck(){
      
            window.location = "http://google.com";   
    }

</script>	


    </body>

</html>
