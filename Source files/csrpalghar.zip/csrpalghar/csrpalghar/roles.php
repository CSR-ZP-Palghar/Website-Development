
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Roles and Responsibility</title>

        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>

        <link rel="stylesheet" href="css/font-awesome.min.css">
	
        <link rel="stylesheet" type="text/css" href="css/animate.min.css">

        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" rel="stylesheet" href="css/carousel.css" />

        <link rel="stylesheet" href="css/isotope/style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="css/style.css" rel="stylesheet">
        <link href="css/responsive.css" rel="stylesheet">

<style>

.dropbtn {
background-color: white;
    padding: 16px;
    border: none;
    text-decoration: none;
}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #ddd}

.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: white;
}
</style>

    </head>

    <body data-spy="scroll" data-target="#header">

        <!--Start Hedaer Section-->
        <section id="header">
            <div class="header-area">
                
                <!--End of top header-->
                <div class="header_menu text-center" data-spy="affix" data-offset-top="20" id="nav">
                    <div class="contact">
                        <nav class="navbar navbar-default zero_mp">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                    <span class="sr-only">Toggle navigation</span>
                                    
                                </button>
                                <a class="navbar-brand custom_navbar-brand" href="#"><img src="img/new_logo.png" width="200px"  alt=""></a>
                            </div>
                            <!--End of navbar-header-->

                            <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="collapse navbar-collapse zero_mp" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right main_menu">
                                    <li  ><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
                                    <li class="active"><a href="roles.php">Roles and Responsibility</a></li>
                                    <li><a href="focusAreas.php">Focus Areas</a></li>
                                    
                                    <li><div class="dropdown">
  <a href="#"><button class="dropbtn">GRAMPANCHAYAT-WISE REQUIREMENTS</button></a>
  <div class="dropdown-content">
    <a href="dahanu.php">DAHANU</a>
    <a href="jawhar.php">JAWHAR</a>
    <a href="mokhada.php">MOKHADA</a>
    <a href="palghar.php">PALGHAR</a>
    <a href="talasari.php">TALASARI</a>
    <a href="vasai.php">VASAI</a>	
    <a href="vikramgarh.php">VIKRAMGARH</a>
    <a href="wada.php">WADA</a>		
  </div>
</div>	</li>
 <li><a href="partners.php">our partners</a></li>

                                    <li><a href="contact.php">contact us</a></li>
                                </ul>

                            <!-- /.navbar-collapse -->
                        </nav>
                        <!--End of nav-->
                    </div>
                    <!--End of container-->
                </div>
                <!--End of header menu-->
            </div>
            <!--end of header area-->
        </section>
       
        <section id="welcome">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="wel_header">
                            <h2>District CSR Cell</h2>
                        </div>
                    </div>
                </div>
                <!--End of row-->
                <div class="row">
                    <div class="col-md-3">
                        <div class="item">
                            <div class="single_item">
                                <div class="item_list">
                                    <div class="welcome_icon">
                                        <i class="fa fa-leaf"></i>
                                    </div>
                                    <br>
                                    <p>Single window system for guidance on CSR projects and all government clearances etc.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-3-->
                    <div class="col-md-3">
                        <div class="item">
                            <div class="single_item">
                                <div class="item_list">
                                    <div class="welcome_icon"><img src="img/help.png">
                                        
                                    </div>
                                   <br>
                                    <p>Single window system for guidance on CSR projects and all government clearances etc.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-3-->
                    <div class="col-md-3">
                        <div class="item">
                            <div class="single_item">
                                <div class="item_list">
                                    <div class="welcome_icon">
                                        <i class="fa fa-tint"></i>
                                    </div>
                                    <br>
                                    <p>Dovetail corporate CSR efforts so that they synergise with existing government programmes</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-3-->
                    <div class="col-md-3">
                        <div class="item">
                            <div class="single_item">
                                <div class="item_list">
                                    <div class="welcome_icon">
                                        <i class="fa fa-cog"></i>
                                    </div>
                                    <br>
                                    <p>Avoid duplication of governments' projects by corporates</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-3-->
                </div>

		<div class="row">
                    <div class="col-md-3">
                        <div class="item">
                            <div class="single_item">
                                <div class="item_list">
                                    <div class="welcome_icon">
                                        <i class="fa fa-leaf"></i>
                                    </div>
                                    <br>
                                    <p>To monitor & review CSR activities implemented by various agencies</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-3-->
                    <div class="col-md-3">
                        <div class="item">
                            <div class="single_item">
                                <div class="item_list">
                                    <div class="welcome_icon">
                                        <i class="fa fa-refresh"></i>
                                    </div>
                                    <br>
                                    <p>Share best practices in CSR among corporates and other stakeholders</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-3-->
                    <div class="col-md-3">
                        <div class="item">
                            <div class="single_item">
                                <div class="item_list">
                                    <div class="welcome_icon">
                                        <i class="glyphicon glyphicon-heart"></i>
                                    </div>
                                    <br>
                                    <p>To monitor the impact of CSR activities on the Human Development Index (HDI) of district / state</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-3-->
                    <div class="col-md-3">
                        <div class="item">
                            <div class="single_item">
                                <div class="item_list">
                                    <div class="welcome_icon">
                                        <i class="fa fa-google-plus-official"></i>
                                    </div>
                                    <br>
                                    <p>Act as a hub and integrate projects by different corporates to create a consolidated large scale transformation with demonstrable results</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-3-->
                </div>

		<div class="row">
                    <div class="col-md-3">
                        <div class="item">
                            <div class="single_item">
                                <div class="item_list">
                                    <div class="welcome_icon">
                                        <i class="fa fa-leaf"></i>
                                    </div>
                                    <br>
                                    <p>Function as a bridge between different stakeholders. i.e. corporates, NGOs, industry associations and other stakeholders</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-3-->
                    <div class="col-md-3">
                        <div class="item">
                            <div class="single_item">
                                <div class="item_list">
                                    <div class="welcome_icon">
                                        <i class="fa fa-refresh"></i>
                                    </div>
                                    <br>
                                    <p>Lorem ipsum dolor sit amet, eu qui modo expetendis reformidans ex sit set appetere sententiae seo eum in simul homero.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-3-->
                    <div class="col-md-3">
                        <div class="item">
                            <div class="single_item">
                                <div class="item_list">
                                    <div class="welcome_icon">
                                        <i class="fa fa-tint"></i>
                                    </div>
                                    <br>
                                    <p>Lorem ipsum dolor sit amet, eu qui modo expetendis reformidans ex sit set appetere sententiae seo eum in simul homero.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-3-->
                    <div class="col-md-3">
                        <div class="item">
                            <div class="single_item">
                                <div class="item_list">
                                    <div class="welcome_icon">
                                        <i class="fa fa-cog"></i>
                                    </div>
                                    <br>
                                    <p>Lorem ipsum dolor sit amet, eu qui modo expetendis reformidans ex sit set appetere sententiae seo eum in simul homero.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-3-->
                </div>
                <!--End of row-->
            </div>
            <!--End of container-->
        </section>
        <!--end of welcome section-->



        <!--Start of volunteer-->
        <section id="volunteer">
            <div class="container">
                <div class="row vol_area">
                   <center> <div class="col-md-15">
                        <div class="volunteer_content">
                            <h3><span>District CSR Co-ordination Committee</span></h3>
                            <p><font size="4px">Under the leadership of the District Collector and the District Development Officer (DDO), a District CSR Co-ordination Committee has been formed which includes all senior government officers in charge of priority sectors i.e. education, health & nutrition, livelihood, infrastructure and support for underprivileged/weaker section. Heritage development is slated to be included in the next phase.</font></p>
                        </div>
                    </div>
			</center>
<br>

<div class="row">
                                <div class="col-md-12 text-center">
                                    <div class="carousel slide" id="fade-quote-carousel" data-ride="carousel" data-interval="3000">
                                        <!-- Carousel indicators -->
                                        <ol class="carousel-indicators">
                                            <li data-target="#fade-quote-carousel" data-slide-to="0" class="active"></li>
                                            <li data-target="#fade-quote-carousel" data-slide-to="1"></li> 
					    
                                        </ol>
                                        <!-- Carousel items -->
                                        <div class="carousel-inner">
                                            <div class="active item">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="testimonial_content">
                                                            <i class="fa fa-quote-left"></i>
                                                            <p> Text here</p>
                                                        </div>
                                                        
                                                    </div>
						   
                                                    <div class="col-md-6">
                                                        
                                                        <div class="testimonial_content">
                                                            <i class="fa fa-quote-left"></i>
                                                            <p>Formulate guidelines for the functioning of the CSR committee.</p>
                                                        </div>
                                                       
                                                    </div>
						<div class="row">
                                                    <div class="col-md-6">
                                                       
                                                        <div class="testimonial_content">
                                                            <i class="fa fa-quote-left"></i>
                                                            <p>Review goals, initiatives and practices for social responsibility. The committee will finalise & continuously review the agenda.</p>
                                                        </div>
                                                        
                                                    </div>
                                                    <div class="col-md-6">
                                                        
                                                        <div class="testimonial_content">
                                                            <i class="fa fa-quote-left"></i>
                                                            <p>Finalise areas of intervention in consultation with various, government departments, NGOs and corporates.</p>
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                                </div>
                                            </div>
					    
                                            <!--End of item with active-->
                                            <div class="item">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        
                                                        <div class="testimonial_content">
                                                            <i class="fa fa-quote-left"></i>
                                                            <p>Extend help in idea conceptualisation, proposal development & liaison with implementing agencies for corporates willing to take up projects.</p>
                                                        </div>
                                                        
                                                    </div>
                                                    <div class="col-md-6">
                                                        
                                                        <div class="testimonial_content">
                                                            <i class="fa fa-quote-left"></i>
                                                            <p>Review and make recommendations on project proposals submitted by government departments, NGOs and corporates.</p>
                                                        </div>
                                                        
                                                    </div>
                                                </div>
						<div class="row">
                                                    <div class="col-md-6">
                                                        
                                                        <div class="testimonial_content">
                                                            <i class="fa fa-quote-left"></i>
                                                            <p>Monitor and review the effectiveness of the projects implemented on a quarterly basis.</p>
                                                        </div>
                                                        
                                                    </div>
                                                    <div class="col-md-6">
                                                        
                                                        <div class="testimonial_content">
                                                            <i class="fa fa-quote-left"></i>
                                                            <p>   </p>
                                                        </div>
                                                        	
                                                    </div>
                                                </div>
                                            </div>
                                            <!--ENd of item-->

                                        </div>
                                    </div>
                                </div>
                            </div>
                    <!--End of col-md-8-->
                    
                    <!--End of col-md-3-->
                </div>
                <!--End of row and vol_area-->
            </div>
            <!--End of container-->
        </section>
        <!--end of volunteer-->

	<section id="portfolio" class="text-center">
            <div class="col-md-12">
                <div class="portfolio_title">
                    <h2>District Core Group</h2>
                    <p><font size=4px>A district core group which includes industry representatives and NGOs along with government officials, has also been formed for aiding the district CSR co-ordination committee in planning, monitoring and facilitating district CSR activities undertaken by different companies in a more coordinated manner.</font></p>
                </div>
            </div>

<section id="blog">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="blog_news">
                            <div class="single_blog_item">
                                
                                <div class="blog_content">
                                   <h3>Climate change is affecting bird migration</h3>
                                    <p class="blog_news_content"></p>
                               
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-4-->
                    <div class="col-md-4">
                        <div class="blog_news">
                            <div class="single_blog_item">
                               
                                <div class="blog_content">
                                    <h3>How to avoid indoor air pollution?</h3>
                                    

                                    <p class="blog_news_content"></p>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-4-->
                    <div class="col-md-4">
                        <div class="blog_news">
                            <div class="single_blog_item">
                                
                                <div class="blog_content">
                                   <h3>Threat to Yellowstone’s grizzly bears.</h3>
                                    

                                    <p class="blog_news_content"></p>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
			
                    <!--End of col-md-4-->
                </div>
		<br>
		<div class="row">
                    <div class="col-md-4">
                        <div class="blog_news">
                            <div class="single_blog_item">
                                
                                <div class="blog_content">
                                    <h3>Climate change is affecting bird migration</h3>
                                    <p class="blog_news_content"> </p>
                               
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-4-->
                    <div class="col-md-4">
                        <div class="blog_news">
                            <div class="single_blog_item">
                               
                                <div class="blog_content">
                                   <h3>How to avoid indoor air pollution?</h3>
                                    

                                    <p class="blog_news_content"></p>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-4-->
                    <div class="col-md-4">
                        <div class="blog_news">
                            <div class="single_blog_item">
                                
                                <div class="blog_content">
                                   <h3>Threat to Yellowstone’s grizzly bears.</h3>
                                    

                                    <p class="blog_news_content"></p>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
			
                    <!--End of col-md-4-->
                </div>
                <!--End of row-->
            </div>
            <!--End of container-->
        </section>
        <!--end of portfolio-->




	<section id="volunteer">
            <div class="container">
                <div class="row vol_area">
                    <div class="col-md-8">
                        <div class="volunteer_content">
                            <h3>Image</h3>
                            <p>place image here in img tag</p>
                        </div>
                    </div>
                    
                </div>
                <!--End of row and vol_area-->
            </div>
            <!--End of container-->
        </section>
        <!--Start of portfolio-->
        <section id="welcome">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="wel_header">
                            <h2>Industry Associations</h2>
                            
                        </div>
                    </div>
                </div>
<font size=5px>
                <div class="row topPadding25" align="left" line-height="1.6px">
<div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 bodytext2 sideR2">A district core group which includes industry representatives and NGOs along with government officials, has also been formed for aiding the district CSR co-ordination committee in <span class="bgTextLemon">planning, monitoring and facilitating district CSR activities undertaken by different companies</span> in a more coordinated manner.</div>
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 rowTop2"><img src="img/csr.png"></div>
<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 rowTop2">
<div class="bodytextGreen bottomPadding15" style="border-bottom:1px solid #D7DF36;"><strong>Taking up joint CSR initiatives as an association.</strong></div>
<div class="bodytextGreen bottomPadding15 topPadding15" style="border-bottom:1px solid #D7DF36;"><strong>Facilitate and co-ordinate CSR activities of its members.</strong></div>
<div class="bodytextGreen bottomPadding15 topPadding15"><strong>Take-up regular discussion of priorities of District Core Co-ordination Committee in their association meetings.</strong></div>
</div>
</div>
 </font>
            <!--End of container-->
        </section>
        <!--end of portfolio-->
</section>


        <?php
       include "footer.php";
       ?>


        <!--Scroll to top-->
        <a href="#" id="back-to-top" title="Back to top">&uarr;</a>
        <!--End of Scroll to top-->


        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <!-- <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js'></script>-->
        <script src="js/jquery-1.12.3.min.js"></script>

        <!--Counter UP Waypoint-->
        <script src="js/waypoints.min.js"></script>
        <!--Counter UP-->
        <script src="js/jquery.counterup.min.js"></script>

        <script>
            //for counter up
            $('.counter').counterUp({
                delay: 10,
                time: 1000
            });
        </script>

        <!--Gmaps-->
        <script src="js/gmaps.min.js"></script>
        <script type="text/javascript">
            var map;
            $(document).ready(function () {
                map = new GMaps({
                    el: '#map',
                    lat: 23.6911078,
                    lng: 90.5112799,
                    zoomControl: true,
                    zoomControlOpt: {
                        style: 'SMALL',
                        position: 'LEFT_BOTTOM'
                    },
                    panControl: false,
                    streetViewControl: false,
                    mapTypeControl: false,
                    overviewMapControl: false,
                    scrollwheel: false,
                });


                map.addMarker({
                    lat: 23.6911078,
                    lng: 90.5112799,
                    title: 'Office',
                    details: {
                        database_id: 42,
                        author: 'Foysal'
                    },
                    click: function (e) {
                        if (console.log)
                            console.log(e);
                        alert('You clicked in this marker');
                    },
                    mouseover: function (e) {
                        if (console.log)
                            console.log(e);
                    }
                });
            });
        </script>
        <!--Google Maps API-->
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBjxvF9oTfcziZWw--3phPVx1ztAsyhXL4"></script>


        <!--Isotope-->
        <script src="js/isotope/min/scripts-min.js"></script>
        <script src="js/isotope/cells-by-row.js"></script>
        <script src="js/isotope/isotope.pkgd.min.js"></script>
        <script src="js/isotope/packery-mode.pkgd.min.js"></script>
        <script src="js/isotope/scripts.js"></script>


        <!--Back To Top-->
        <script src="js/backtotop.js"></script>


        <!--JQuery Click to Scroll down with Menu-->
        <script src="js/jquery.localScroll.min.js"></script>
        <script src="js/jquery.scrollTo.min.js"></script>
        <!--WOW With Animation-->
        <script src="js/wow.min.js"></script>
        <!--WOW Activated-->
        <script>
            new WOW().init();
        </script>


        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="js/bootstrap.min.js"></script>
        <!-- Custom JavaScript-->
        <script src="js/main.js"></script>
    </body>

</html>
